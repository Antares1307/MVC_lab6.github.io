package lab6_mvc_validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

// Cung cấp lớp thực tế có quy tắc nghiệp vụ để xác thực
@Constraint(validatedBy = CourseCodeConstraintValidator.class)

// Dùng chú thích trên METHOD or FIELD
@Target({ ElementType.METHOD, ElementType.FIELD })

// Giứ chú thích trong bao lâu
@Retention(RetentionPolicy.RUNTIME)
public @interface CourseCode {
	
	// Định nghĩa mặc định cho course code.
	public String value() default "LUV";
	
	// Định nghĩa mặc định cho error message.
	public String message() default "must start with LUV";
	
	// Định nghĩa mặc định cho groups.
	public Class<?>[] groups() default {};
	
	// Định nghĩa mặc định cho payloads.
	public Class<? extends Payload>[] payload() default {};
} 
