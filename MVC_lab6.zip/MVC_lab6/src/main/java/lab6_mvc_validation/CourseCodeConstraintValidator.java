package lab6_mvc_validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

// truyền vào chú thích CourseCode và kiểu dữ liệu đang xác thực
public class CourseCodeConstraintValidator 
    implements ConstraintValidator<CourseCode, String>{
	
	private String coursePrefix; // thiết lập chú thích
	
	@Override
	public void initialize(CourseCode theCourseCode) {
		coursePrefix = theCourseCode.value();
	}
	
	@Override
	public boolean isValid(String theCode,
			      ConstraintValidatorContext theConstraintValidatorContext) {
		boolean result;
		
		if(theCode != null) {
			result = theCode.startsWith(coursePrefix);		
		} else {
			result = true;
		}
		
		return result;
	}
}
